$(document).ready(function() {
    $('select').material_select();
    $('ul.tabs').tabs();
});
        

function showToast(){
	console.log('test');
	 Materialize.toast('Mensagem enviada', 4000);
}

